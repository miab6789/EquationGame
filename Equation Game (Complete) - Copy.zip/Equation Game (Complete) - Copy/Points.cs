﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Equation_Game
{
    class Points
    {
        //Data member ========================
        private int score = 0;
        //end data members =====================
        //Constructor
        //Creates a Points object
        //Parameters: none
        //Returns: void (constructor)
        public Points()
        {
            score = 0;
        }
        
        //Getters and setters =====================
        //Get and set values for data member(s)
        //Parameters: int for Setter, none for Getters
        //Returns: int for Getters, none for Setters
        public int GetScore()
        {
            return score;
        }
        public void SetScore(int _score)
        {
            score = _score;
        }
        //end getters and setters

        //Member methods
        //add, subtract, and reset as names imply
        //parameters:none
        //return: int
        public int Add()
        {
           return ++score;
        }
        public int Subtract()
        {
            return --score;
        }
        public int Reset()
        {
            score = 0;
            return score;
        }
    }
}

﻿//this class kinda creates the equation and returns it to form2  where we call it

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Equation_Game
{
    class RollDice
    {
        //declare constants, arrays, and random objects as well as call MathCalculatons class
        //arrays
        
        //arrays
        char[] opperator = new char[SWITCH_MAX];
        public int[] oppChosen = new int[MAX_OPP];
        //constants
        private const int MAX_OPP = 5;
        private const int MAX = 6;
        private const int SWITCH_MAX = 3;
        //int
        int oppCount = 0;
        //random object
        Random rand = new Random();
        //refrence object
        MathClaculations calc = new MathClaculations();
        

        //Constructor
        public RollDice()
        {
            opperator[oppCount] = '+';
            opperator[++oppCount] = '-';
            opperator[++oppCount] = '*';
        }

        //DiceRollMovement method
        //fills the dice value array with random numbers between 0-5
        //parameters: int[] (empty to fill)
        //return: int[] (full same array)
        public int[] DiceRollMovement(int[] diceNums)
        {
            //fills all the spots in the array with random numbers 
            for (int i = 0; i < MAX; ++i)
            {
                diceNums[i] = rand.Next(0, MAX);
            }

            return diceNums;
        }

        //SwitchCheck method
        //calls switch method in order to choose operator randomly
        //parameters: int[]
        //returns: string
        public string SwitchCheck(int[] diceNums, int maxTurn)
        {
            //declare strings and characters
            string equation = "";
            int diceCounter = 0;
            //int maxTurn = 5;

            //create equation as well as find the answer then return it as well as save the equation
            equation = $"{diceNums[diceCounter]+1}";
            for (int i = 0; i < maxTurn; i++)
            {
                equation += $" {opperator[oppChosen[diceCounter++]]} {diceNums[diceCounter] + 1}";
            }

            return equation;
        }//end of switchcheck method

        //opperators method
        //assings the operators using numbers 0-2 in an array
        //parameters: none
        //returns: void
        public void Opperators()
        {
            //fills the array all the way with random numbers
            for(int i = 0;  i < MAX_OPP;  ++i)
            {
                oppChosen[i] = rand.Next(0, SWITCH_MAX);
            }
        }

        //AnswerCreation method
        //generates the answer by calling the calculate method
        //parameters: int[], int
        //returns: int (the actual answer)
        public int AnswerCreation(int[] diceNums, int max)
        {
            //create the answer integer
            int answer = 0;
            //send in the numbers on the dice and the operators chosen arrays to math calculations to calculate
            answer = calc.Calculate(ref diceNums, oppChosen, max);
            //return the answer
            return answer;
        }
    }//end of class
}//end of namespace
